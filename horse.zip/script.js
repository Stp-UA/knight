let dlina = 3;          // длина очереди ходов (очереди массивов old_x, old_y)

// массивы old_x и old_y хранят позиции фигуры: текущая(там где фигура), прошлые (зеленые), последняя (затереть)
//   нулевой индекс - то что затереть, текущая позиция с индексом dlina-1
let old_x = [];         // предыдущие значения x
let old_y = [];         // предыдущие значения y

let correct = [];       // массив возможных ходов для фигуры, формах XY
let newFig = true;      // выбрана новая фигура которой еще нет на доске
let choice = '';        // текущий выбор фигуры

// позиция где был нажат курсор
let x = 0;
let y = 0;
// временные переменные для циклов и т.д.
let i = 0;
let k = 0;
let m = 0;
let out = '';       // для рисования доски

function onMenu() {
    if (this.id != choice) {
        this.classList.add('on');
    }
}

function offMenu() {
    if (this.id != choice) {
        this.classList.remove('on');
    }
}

function downMenu() {
    clearAll();
    newFig = true;
    // убираем предыдущий выбор меню
    if (choice) {
        document.querySelector(`#${choice}`).classList.remove('on');
    }
    choice = this.id;
    document.querySelector(`#${choice}`).classList.add('on');
    // ставим обработчики в каждую клетку
    document.querySelectorAll('.chess-block').forEach(element => {
        element.onclick = eval(choice);
    });
}

function clearAll() {
    clear();
    document.querySelectorAll('.chess-block').forEach(element => {
        element.classList.remove('oldpos');
    })
}

function clear() {
    correct = [];
    document.querySelectorAll('.chess-block').forEach(element => {
        element.classList.remove('move', 'active', 'knight', 'bishop', 'rook', 'queen');
    })
}

function move(x, y) {
    if (x >= 0 && x < 8 && y >= 0 && y < 8) {
        document.querySelector(`[data-x="${x}"][data-y="${y}"]`).classList.add('move');
        return true;
    } else {
        return false;
    }
}

function oldPos() {
    // сохраняем нажатую клетку
    x = +this.dataset.x;
    y = +this.dataset.y;
    let xy = `${x}${y}`;                    // текущая позиция для определения корректности хода
    if (newFig) {                           // первое вхождение для фигуры?
        newFig = false;
    } else {
        // если ход корректный то добавляем зеленым предыдущую позицию фигуры
        // если ход некорректны - выходим из функции и ничего не делаем
        if (correct.indexOf(xy) != -1) {    // корректный ход?
            i = old_x.length - 1;
            document.querySelector(`[data-x="${old_x[i]}"][data-y="${old_y[i]}"]`).classList.add('oldpos');
        } else {
            return false;
        }
    }
    clear();            // очищаем доску за исключением предыдущей позиции (добавляем зеленое)
    // сохраняем текущую позицию в очередь ходов
    old_x.push(x);
    old_y.push(y);
    // если очередь заполнилась то удаляем устаревшую позицию фигуры (убираем зеленое)
    if (old_x.length == dlina) {
        document.querySelector(`[data-x="${old_x.shift()}"][data-y="${old_y.shift()}"]`).classList.remove('oldpos');
    }
    return true;
}

function knight() {
    if (oldPos.call(this)) {
        // выводим фигуру в "нажатую" клетку
        document.querySelector(`[data-x="${x}"][data-y="${y}"]`).classList.add('knight');
        // выводим возможные ходы для фигуры
        if (move(x - 2, y - 1)) correct.push(`${x - 2}${y - 1}`);
        if (move(x - 2, y + 1)) correct.push(`${x - 2}${y + 1}`);
        if (move(x - 1, y - 2)) correct.push(`${x - 1}${y - 2}`);
        if (move(x - 1, y + 2)) correct.push(`${x - 1}${y + 2}`);
        if (move(x + 1, y - 2)) correct.push(`${x + 1}${y - 2}`);
        if (move(x + 1, y + 2)) correct.push(`${x + 1}${y + 2}`);
        if (move(x + 2, y - 1)) correct.push(`${x + 2}${y - 1}`);
        if (move(x + 2, y + 1)) correct.push(`${x + 2}${y + 1}`);
    }
}

function bishop() {
    if (oldPos.call(this)) {
        // выводим фигуру в "нажатую" клетку
        document.querySelector(`[data-x="${x}"][data-y="${y}"]`).classList.add('bishop');
        // выводим возможные ходы для фигуры
        for (i = 1; i < 8; i++) {
            if (move(x - i, y - i)) correct.push(`${x - i}${y - i}`);
            if (move(x - i, y + i)) correct.push(`${x - i}${y + i}`);
            if (move(x + i, y - i)) correct.push(`${x + i}${y - i}`);
            if (move(x + i, y + i)) correct.push(`${x + i}${y + i}`);
        }
    }
}

function rook() {
    if (oldPos.call(this)) {
        // выводим фигуру в "нажатую" клетку
        document.querySelector(`[data-x="${x}"][data-y="${y}"]`).classList.add('rook');
        // выводим возможные ходы для фигуры
        for (i = 1; i < 8; i++) {
            if (move(x - i, y)) correct.push(`${x - i}${y}`);
            if (move(x + i, y)) correct.push(`${x + i}${y}`);
            if (move(x, y - i)) correct.push(`${x}${y - i}`);
            if (move(x, y + i)) correct.push(`${x}${y + i}`);
        }
    }
}

function queen() {
    if (oldPos.call(this)) {
        // выводим фигуру в "нажатую" клетку
        document.querySelector(`[data-x="${x}"][data-y="${y}"]`).classList.add('queen');
        // выводим возможные ходы для фигуры
        for (i = 1; i < 8; i++) {
            if (move(x - i, y - i)) correct.push(`${x - i}${y - i}`);
            if (move(x - i, y + i)) correct.push(`${x - i}${y + i}`);
            if (move(x + i, y - i)) correct.push(`${x + i}${y - i}`);
            if (move(x + i, y + i)) correct.push(`${x + i}${y + i}`);
            if (move(x - i, y)) correct.push(`${x - i}${y}`);
            if (move(x + i, y)) correct.push(`${x + i}${y}`);
            if (move(x, y - i)) correct.push(`${x}${y - i}`);
            if (move(x, y + i)) correct.push(`${x}${y + i}`);
        }
    }
}

// Здесь начинается исполняемый код
// --------------------------------
// рисуем доску
for (i = 0; i < 8; i++) {
    for (k = 0; k < 8; k++) {
        if (m % 2) {
            out += `<div class="chess-block bg-black" data-x="${k}" data-y="${i}"></div>`;
        }
        else {
            out += `<div class="chess-block" data-x="${k}" data-y="${i}"></div>`;
        }
        m++;
    }
    m++;
}
document.querySelector('#board').innerHTML = out;

// ставим обработчики на меню
document.querySelectorAll('.button').forEach(element => {
    element.addEventListener('mouseover', onMenu);
    element.addEventListener('mouseout', offMenu);
    element.addEventListener('mousedown', downMenu);
})
